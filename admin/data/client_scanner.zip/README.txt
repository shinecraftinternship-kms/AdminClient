System Scanner Pro Client
=========================

1. Extract all files from this zip to a folder
2. Double-click run.bat to launch the scanner
   (or rename client_scanner.dat to .exe and run it directly)
