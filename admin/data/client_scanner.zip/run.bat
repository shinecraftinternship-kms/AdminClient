@echo off
ren client_scanner.dat client_scanner.exe >nul 2>&1
start client_scanner.exe
